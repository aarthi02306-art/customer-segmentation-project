# Customer Segmentation Project

Segmenting mall customers by behavior and demographics using **K-Means clustering** in Python.

## Objective
Group customers based on Age, Annual Income and Spending Score, analyze purchase behavior of each group, and suggest targeted marketing strategies.

## Dataset
[Mall Customers Dataset (Kaggle)](https://www.kaggle.com/datasets/vjchoudhary7/customer-segmentation-tutorial-in-python) - 200 customers with CustomerID, Gender, Age, Annual Income (k$) and Spending Score (1-100).

## Tools & Libraries
Python, pandas, NumPy, scikit-learn, matplotlib, seaborn

## Methodology
1. Data loading, cleaning and checks (missing values, duplicates)
2. Exploratory data analysis (distributions, gender split, correlation)
3. Feature scaling with `StandardScaler`
4. Choosing K using the Elbow method and Silhouette score
5. K-Means clustering (K = 5)
6. Segment profiling and naming
7. Visualizations and marketing recommendations

## Customer Segments
| Segment | Profile | Marketing Action |
|---|---|---|
| Premium Customers | High income, high spending | Loyalty rewards, VIP membership |
| Potential Customers | High income, low spending | Personalized promotions |
| Impulsive Buyers | Low income, high spending | Limited-time offers, flash sales |
| Budget Customers | Low income, low spending | Discount coupons |
| Regular Customers | Average income and spending | Retention and referral programs |

## Visualizations
- Elbow curve and Silhouette score
- Income vs Spending scatter plot with centroids
- Segment size (bar and pie chart)
- Average Age / Income / Spending per segment
- Age distribution and gender mix per segment
- 3D segment plot

## How to Run
1. Clone this repository or open `Customer_Segmentation.ipynb` in Google Colab / Jupyter Notebook.
2. Keep `Mall_Customers.csv` in the same folder.
3. Install requirements: `pip install -r requirements.txt`
4. Run all cells (Run All).

## Outputs
- `customer_segments.csv` - each customer with assigned cluster and segment
- `segment_summary.csv` - average profile of each segment

## Key Insights
- Premium customers are the most valuable group and should be retained with loyalty benefits.
- High-income, low-spending customers are the biggest growth opportunity.
- Targeted campaigns per segment work better than one generic campaign.

## Future Improvements
- Add purchase history and visit frequency as features
- Compare with Hierarchical Clustering and DBSCAN
- Build a Power BI / Streamlit dashboard
